﻿#include "NormalCourse.h"

void NormalCourse::stop()
{
  lineTracerWalker.setForward(0);
}